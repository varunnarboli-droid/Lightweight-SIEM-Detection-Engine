"""
Simple log generator for demoing the SIEM.
Generates various sample syslog-like lines to sample_logs.txt
"""
import random, datetime, argparse

HOSTS = ["web1", "db1", "proxy1", "app1", "workstation-01"]
SERVICES = ["sshd", "nginx", "app", "kernel", "auth"]

MESSAGES = [
    "Failed password for invalid user admin from 192.168.1.50 port 45444",
    "Accepted password for user alice from 10.0.0.8 port 53421",
    "Connection refused: client 203.0.113.5",
    "GET /wp-admin.php 200 5123",
    "Possible SQL injection attempt in query: SELECT * FROM users WHERE id=' OR 1=1 --",
    "User bob added to sudoers",
    "Multiple authentication failures for root",
    "CRON job started: backup.sh",
    "Excessive 404 errors from 198.51.100.23",
    "Malware signature detected in file upload: trojan.exe",
    "Privilege escalation: setuid executed",
    "Unexpected service crash: segmentation fault"
]

def generate(n=50, out='sample_logs.txt'):
    now = datetime.datetime.utcnow()
    with open(out, 'w') as f:
        for i in range(n):
            ts = (now + datetime.timedelta(seconds=i)).isoformat()
            host = random.choice(HOSTS)
            svc = random.choice(SERVICES)
            msg = random.choice(MESSAGES)
            f.write(f"{ts} {host} {svc}: {msg}\\n")
    print(f"Generated {n} log lines to {out}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--n', type=int, default=50)
    parser.add_argument('--out', default='sample_logs.txt')
    args = parser.parse_args()
    generate(n=args.n, out=args.out)
