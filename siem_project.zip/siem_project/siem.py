"""
Simple SIEM Project (siem.py)
- Ingests plain text logs (one-per-line)
- Parses each log using a simple regex to extract timestamp, host, service, message
- Loads detection rules from rules.json (regex patterns)
- Generates alerts.json, alerts.log, and a basic HTML report (report.html)
Usage:
    python siem.py --logs sample_logs.txt
"""
import re, json, argparse, datetime, html, os
from typing import List, Dict

LOG_LINE_RE = re.compile(r'^(?P<ts>\S+)\s+(?P<host>\S+)\s+(?P<service>\S+):\s+(?P<msg>.*)$')

def parse_line(line: str):
    m = LOG_LINE_RE.match(line.strip())
    if not m:
        return None
    return m.groupdict()

def load_rules(path: str):
    with open(path, 'r') as f:
        rules = json.load(f)
    # compile regex
    for r in rules:
        r['re'] = re.compile(r['pattern'], re.IGNORECASE)
    return rules

def analyze_logs(log_path: str, rules_path: str):
    rules = load_rules(rules_path)
    alerts = []
    with open(log_path, 'r') as f:
        for lineno, line in enumerate(f, start=1):
            parsed = parse_line(line)
            if not parsed:
                continue
            for rule in rules:
                if rule['re'].search(parsed['msg']):
                    alert = {
                        "timestamp": parsed['ts'],
                        "host": parsed['host'],
                        "service": parsed['service'],
                        "message": parsed['msg'],
                        "rule": rule['name'],
                        "severity": rule['severity'],
                        "description": rule.get('description',''),
                        "line": lineno
                    }
                    alerts.append(alert)
    return alerts

def save_alerts(alerts: List[Dict], outdir: str):
    os.makedirs(outdir, exist_ok=True)
    json_path = os.path.join(outdir, 'alerts.json')
    log_path = os.path.join(outdir, 'alerts.log')
    with open(json_path, 'w') as f:
        json.dump(alerts, f, indent=2)
    with open(log_path, 'w') as f:
        for a in alerts:
            f.write(f"[{a['severity']}] {a['timestamp']} {a['host']} {a['service']}: {a['rule']} - {a['message']}\n")
    return json_path, log_path

def generate_report(alerts: List[Dict], outdir: str):
    report_path = os.path.join(outdir, 'report.html')
    total = len(alerts)
    by_sev = {}
    for a in alerts:
        by_sev.setdefault(a['severity'], 0)
        by_sev[a['severity']] += 1
    # simple HTML
    html_parts = []
    html_parts.append("<html><head><meta charset='utf-8'><title>SIEM Report</title></head><body>")
    html_parts.append("<h1>SIEM Analysis Report</h1>")
    html_parts.append(f"<p>Generated: {datetime.datetime.now().isoformat()}</p>")
    html_parts.append(f"<p>Total alerts: {total}</p>")
    html_parts.append("<h2>Alerts by severity</h2><ul>")
    for sev, cnt in sorted(by_sev.items(), key=lambda x: x[0], reverse=True):
        html_parts.append(f"<li>{html.escape(sev)}: {cnt}</li>")
    html_parts.append("</ul>")
    if alerts:
        html_parts.append("<h2>Alert details</h2><table border='1' cellpadding='4'><tr><th>#</th><th>Time</th><th>Host</th><th>Service</th><th>Severity</th><th>Rule</th><th>Message</th></tr>")
        for i,a in enumerate(alerts, start=1):
            html_parts.append("<tr>")
            html_parts.append(f"<td>{i}</td><td>{html.escape(a['timestamp'])}</td><td>{html.escape(a['host'])}</td><td>{html.escape(a['service'])}</td><td>{html.escape(a['severity'])}</td><td>{html.escape(a['rule'])}</td><td>{html.escape(a['message'])}</td>")
            html_parts.append("</tr>")
        html_parts.append("</table>")
    html_parts.append("</body></html>")
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\\n'.join(html_parts))
    return report_path

def main():
    parser = argparse.ArgumentParser(description="Simple SIEM analyzer")
    parser.add_argument('--logs', required=True, help='Path to log file (one-per-line)')
    parser.add_argument('--rules', default='rules.json', help='Path to rules.json')
    parser.add_argument('--out', default='siem_output', help='Output directory')
    args = parser.parse_args()

    alerts = analyze_logs(args.logs, args.rules)
    json_path, log_path = save_alerts(alerts, args.out)
    report_path = generate_report(alerts, args.out)
    print(f"Scanned logs: {args.logs}")
    print(f"Alerts found: {len(alerts)}")
    print(f"Alerts saved to: {json_path}, {log_path}")
    print(f"HTML report: {report_path}")

if __name__ == '__main__':
    main()
